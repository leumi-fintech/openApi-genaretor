declare function _exports(func: Function): string;
export = _exports;
