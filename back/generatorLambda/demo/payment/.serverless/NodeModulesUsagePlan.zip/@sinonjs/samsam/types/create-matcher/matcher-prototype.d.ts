export function or(valueOrMatcher: any, ...args: any[]): any;
export function and(valueOrMatcher: any, ...args: any[]): any;
