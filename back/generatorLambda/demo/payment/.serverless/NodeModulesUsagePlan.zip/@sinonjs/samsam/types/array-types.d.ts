export = ARRAY_TYPES;
declare var ARRAY_TYPES: (ArrayConstructor | Int8ArrayConstructor)[];
