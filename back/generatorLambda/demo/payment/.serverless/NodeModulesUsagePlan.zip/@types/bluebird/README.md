# Installation
> `npm install --save @types/bluebird`

# Summary
This package contains type definitions for bluebird (https://github.com/petkaantonov/bluebird).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bluebird.

### Additional Details
 * Last updated: Wed, 28 Oct 2020 18:21:10 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Leonard Hecker](https://github.com/lhecker).
